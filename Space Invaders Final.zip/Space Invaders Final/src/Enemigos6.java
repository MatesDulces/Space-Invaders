import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Enemigos6 {
    private static final int PANEL_SIZE = 31; // Tamaño del enemigo
    private static final int NUM_ENEMIES_PER_ROW = 10; // Número de enemigos por fila
    private static final int NUM_ROWS = 4; // Número de filas de enemigos
    private static final int TIMER_DELAY = 15; // Retraso del temporizador en milisegundos
    private static final int BULLET_DELAY = 300; // Ajusta el retraso para disparos enemigos (más bajo = disparos más rápidos)
    private static final int BULLET_MOVE_STEP = 5; // Paso de movimiento de la bala
    private static final int BULLET_MOVE_INTERVAL = 10; // Intervalo de actualización de las balas en milisegundos
    private static final int GRADUAL_MOVE_STEP = 4; // Paso de movimiento gradual hacia abajo en píxeles (aumentado)
    private static final int GRADUAL_MOVE_INTERVAL = 100; // Intervalo de actualización del movimiento gradual en milisegundos
    private int enemiesRemoved = 0;
    private static final int VICTORY_THRESHOLD = 40;
    private JPanel[][] enemyPanels = new JPanel[NUM_ROWS][NUM_ENEMIES_PER_ROW];
    private Timer movementTimer;
    private Timer shootingTimer;
    private Timer bulletMovementTimer;
    private Timer gradualMoveTimer;
    private JPanel parentPanel;
    private int bottomLimit; // Límite inferior para el movimiento de los enemigos
    private Nivel5 nivel5; // Referencia al nivel para manejar la pérdida de vida
    private Image enemyImage;
    private List<JPanel> enemyBullets = new ArrayList<>();

    // Parámetros para el movimiento circular
    private static final int CIRCLE_RADIUS = 80;
    private static final int CIRCLE_SPEED = 2; // Velocidad angular en píxeles

    private List<EnemyGroup> enemyGroups = new ArrayList<>();

    public Enemigos6(JPanel parent, int bottomLimit) {
        this.parentPanel = parent;
        this.bottomLimit = bottomLimit;
        this.nivel5 = (Nivel5) SwingUtilities.getWindowAncestor(parent); // Obtener referencia a Nivel5
        this.enemyImage = new ImageIcon("enemies.png").getImage(); // Cargar imagen del enemigo
        initializeEnemies();
        startMovement();
        startShooting();
        startBulletMovement();
        startGradualMove(); // Iniciar el movimiento gradual hacia abajo
    }

    private void initializeEnemies() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        g.drawImage(enemyImage, 0, 0, PANEL_SIZE, PANEL_SIZE, this); // Dibujar la imagen del enemigo
                    }
                };
                panel.setBackground(Color.BLACK); // Establecer el fondo a negro
                panel.setBounds(
                    63 + col * (PANEL_SIZE + 20),
                    11 + row * (PANEL_SIZE + 20),
                    PANEL_SIZE, PANEL_SIZE
                );
                parentPanel.add(panel);
                enemyPanels[row][col] = panel;
            }
        }

        // Agrupar enemigos para movimiento circular
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int centerX = panel.getX() + PANEL_SIZE / 2;
                    int centerY = panel.getY() + PANEL_SIZE / 2;
                    enemyGroups.add(new EnemyGroup(panel, centerX, centerY, CIRCLE_RADIUS, CIRCLE_SPEED));
                }
            }
        }
    }

    private void startMovement() {
        movementTimer = new Timer();
        movementTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> moveEnemies());
            }
        }, 0, TIMER_DELAY);
    }

    private void startShooting() {
        shootingTimer = new Timer();
        shootingTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> shoot());
            }
        }, 0, BULLET_DELAY); // Disparar con mayor frecuencia
    }

    private void startBulletMovement() {
        bulletMovementTimer = new Timer();
        bulletMovementTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> moveBullets());
            }
        }, 0, BULLET_MOVE_INTERVAL); // Intervalo de actualización de las balas
    }

    private void startGradualMove() {
        gradualMoveTimer = new Timer();
        gradualMoveTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> gradualMoveDown());
            }
        }, 0, GRADUAL_MOVE_INTERVAL); // Intervalo de actualización del movimiento gradual
    }

    private void moveEnemies() {
        for (EnemyGroup group : enemyGroups) {
            group.move();
        }
    }

    private void gradualMoveDown() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int newY = panel.getY() + GRADUAL_MOVE_STEP;
                    if (newY >= bottomLimit - 10) {
                        // Notificar al Nivel5 sobre la pérdida de vida
                        nivel5.loseLife();
                        newY = 11; // Resetear a la parte superior si alcanza el límite
                    }
                    panel.setLocation(panel.getX(), newY);
                }
            }
        }
    }

    private void shoot() {
        Random rand = new Random();
        int row = rand.nextInt(NUM_ROWS);
        int col = rand.nextInt(NUM_ENEMIES_PER_ROW);
        JPanel enemy = enemyPanels[row][col];

        if (enemy != null) {
            int x = enemy.getX() + PANEL_SIZE / 2 - 2; // Centrar el disparo
            int y = enemy.getY() + PANEL_SIZE; // Disparar desde la parte inferior del enemigo

            JPanel bullet = new JPanel();
            bullet.setBackground(Color.GREEN);
            bullet.setOpaque(true);
            bullet.setBounds(x, y, 4, 10); // Tamaño de la bala

            parentPanel.add(bullet);
            enemyBullets.add(bullet);
        }
    }

    private void moveBullets() {
        List<JPanel> toRemoveBullets = new ArrayList<>();
        for (JPanel bullet : enemyBullets) {
            bullet.setLocation(bullet.getX(), bullet.getY() + BULLET_MOVE_STEP); // Mover la bala hacia abajo
            if (bullet.getY() > parentPanel.getHeight() || checkBulletCollisionWithPlayer(bullet)) {
                toRemoveBullets.add(bullet);
                parentPanel.remove(bullet);
            }
        }
        enemyBullets.removeAll(toRemoveBullets);
    }

    private boolean checkBulletCollisionWithPlayer(JPanel bullet) {
        Rectangle bulletBounds = bullet.getBounds();
        Component[] components = parentPanel.getComponents();
        for (Component component : components) {
            if (component instanceof Jugador5) {
                Jugador5 player = (Jugador5) component;
                Rectangle playerBounds = player.getBounds();
                if (bulletBounds.intersects(playerBounds)) {
                    nivel5.loseLife(); // Restar vida al jugador
                    return true; // Colisión detectada
                }
            }
        }
        return false;
    }

    public JPanel getEnemy(int row, int col) {
        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
            return enemyPanels[row][col];
        }
        return null;
    }

    public int getNumRows() {
        return NUM_ROWS;
    }

    public int getNumEnemiesPerRow() {
        return NUM_ENEMIES_PER_ROW;
    }

    

    // Clase interna para manejar el movimiento circular de los enemigos
    private static class EnemyGroup {
        private JPanel enemy;
        private int centerX;
        private int centerY;
        private int radius;
        private double angle = 0;
        private int speed;

        public EnemyGroup(JPanel enemy, int centerX, int centerY, int radius, int speed) {
            this.enemy = enemy;
            this.centerX = centerX;
            this.centerY = centerY;
            this.radius = radius;
            this.speed = speed;
        }

        public void move() {
            angle += speed * Math.PI / 180; // Convertir velocidad a radianes
            int x = (int) (centerX + radius * Math.cos(angle));
            int y = (int) (centerY + radius * Math.sin(angle));
            enemy.setLocation(x - PANEL_SIZE / 2, y - PANEL_SIZE / 2);
        }
    }
    public boolean allEnemiesRemoved() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                if (enemyPanels[row][col] != null) {
                    return false;
                }
            }
        }
        return true;
    } 
    
    public void stopTimers() {
        if (movementTimer != null) {
            movementTimer.cancel();
        }
        if (shootingTimer != null) {
            shootingTimer.cancel();
        }
        if (bulletMovementTimer != null) {
            bulletMovementTimer.cancel();
        }
    }
    
    public void removeEnemy(int row, int col) {
        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
            JPanel enemy = enemyPanels[row][col];
            if (enemy != null) {
                parentPanel.remove(enemy);
                enemyPanels[row][col] = null; // Marcar como eliminado
                parentPanel.repaint();
                enemiesRemoved++;
                checkForVictory(); // Verificar si se alcanza el umbral de victoria
            }
        }
    }

    private void checkForVictory() {
        if (enemiesRemoved >= VICTORY_THRESHOLD) {
            // Notificar al Nivel5 sobre la victoria
            nivel5.showVictoryMessage();
        }
    }
}
