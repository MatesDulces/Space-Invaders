	import javax.swing.*;
	import java.awt.*;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	
	public class Enemigos2 {
	    private static final int PANEL_SIZE = 31; // Tamaño del enemigo
	    private static final int NUM_ENEMIES_PER_ROW = 10; // Número de enemigos por fila
	    private static final int NUM_ROWS = 4; // Número de filas de enemigos
	    private static final int MOVE_STEP = 1; // Paso de movimiento horizontal
	    private static final int TIMER_DELAY = 15; // Retraso del temporizador en milisegundos
	    private static final int MOVE_DOWN_STEP = 20; // Paso de movimiento vertical
	    private static final int HORIZONTAL_GAP = 20; // Espacio horizontal entre enemigos
	    private static final int VERTICAL_GAP = 20; // Espacio vertical entre enemigos
	
	    private JPanel[][] enemyPanels = new JPanel[NUM_ROWS][NUM_ENEMIES_PER_ROW];
	    private int direction = 1;
	    private boolean hitLeftEdge = false;
	    private boolean hitRightEdge = false;
	    private Timer timer;
	    private JPanel parentPanel;
	    private int bottomLimit; // Límite inferior para el movimiento de los enemigos
	    private Nivel1 nivel1; // Referencia al nivel para manejar la pérdida de vida
	    private Image enemyImage;
	
	    public Enemigos2(JPanel parent, int bottomLimit, Nivel1 nivel1) {
	        this.parentPanel = parent;
	        this.bottomLimit = bottomLimit; 
	        this.nivel1 = nivel1;
	        this.enemyImage = new ImageIcon("enemies.png").getImage(); // Cargar imagen del enemigo
	        initializeEnemies();
	        startMovement();
	    }
	
	    private void initializeEnemies() {
	        for (int row = 0; row < NUM_ROWS; row++) {
	            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
	                enemyPanels[row][col] = new JPanel() {
	                    @Override
	                    protected void paintComponent(Graphics g) {
	                        super.paintComponent(g);
	                        g.drawImage(enemyImage, 0, 0, PANEL_SIZE, PANEL_SIZE, this); // Dibujar la imagen del enemigo
	                    }
	                };
	                enemyPanels[row][col].setBackground(Color.BLACK); // Establecer el fondo a negro
	                enemyPanels[row][col].setBounds(
	                    63 + col * (PANEL_SIZE + HORIZONTAL_GAP),
	                    11 + row * (PANEL_SIZE + VERTICAL_GAP),
	                    PANEL_SIZE, PANEL_SIZE
	                );
	                parentPanel.add(enemyPanels[row][col]);
	            }
	        }
	    }
	
	    private void startMovement() {
	        timer = new Timer(TIMER_DELAY, new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                moveEnemies();
	                if (nivel1 != null && nivel1.isVisible()) {
	                    if (allEnemiesRemoved()) {
	                        nivel1.checkLevelComplete(); // Verificar si el nivel está completo
	                    }
	                }
	            }
	        });
	        timer.start();
	    }
	
	    private void moveEnemies() {
	        hitLeftEdge = false;
	        hitRightEdge = false;
	
	        for (int row = 0; row < NUM_ROWS; row++) {
	            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
	                JPanel panel = enemyPanels[row][col];
	                if (panel != null) {
	                    if (panel.getX() <= 0) {
	                        hitLeftEdge = true;
	                    }
	                    if (panel.getX() + PANEL_SIZE >= parentPanel.getWidth()) {
	                        hitRightEdge = true;
	                    }
	                }
	            }
	        }
	
	        if (hitLeftEdge) {
	            direction = 1;
	            moveDown();
	        } else if (hitRightEdge) {
	            direction = -1;
	            moveDown();
	        }
	
	        for (int row = 0; row < NUM_ROWS; row++) {
	            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
	                JPanel panel = enemyPanels[row][col];
	                if (panel != null) {
	                    int newX = panel.getX() + MOVE_STEP * direction;
	                    if (newX >= 0 && newX + PANEL_SIZE <= parentPanel.getWidth()) {
	                        panel.setLocation(newX, panel.getY());
	                    }
	                }
	            }
	        }
	    }
	
	    private void moveDown() {
	        for (int row = 0; row < NUM_ROWS; row++) {
	            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
	                JPanel panel = enemyPanels[row][col];
	                if (panel != null) {
	                    int newY = panel.getY() + MOVE_DOWN_STEP;
	                    if (newY >= bottomLimit - 10) {
	                        // Notificar al Nivel1 sobre la pérdida de vida
	                        nivel1.loseLife();
	                        newY = 11; // Resetear a la parte superior si alcanza el límite
	                    }
	                    panel.setLocation(panel.getX(), newY);
	                }
	            }
	        }
	    }
	
	    public JPanel getEnemy(int row, int col) {
	        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
	            return enemyPanels[row][col];
	        }
	        return null;
	    }
	
	    public int getNumRows() {
	        return NUM_ROWS;
	    }
	
	    public int getNumEnemiesPerRow() {
	        return NUM_ENEMIES_PER_ROW;
	    }
	
	    public void removeEnemy(int row, int col) {
	        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
	            JPanel enemy = enemyPanels[row][col];
	            if (enemy != null) {
	                parentPanel.remove(enemy);
	                enemyPanels[row][col] = null; // Marcar como eliminado
	                parentPanel.repaint();
	            }
	        }
	    }
	
	    public boolean allEnemiesRemoved() {
	        for (int row = 0; row < NUM_ROWS; row++) {
	            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
	                if (enemyPanels[row][col] != null) {
	                    return false; // Hay enemigos restantes
	                }
	            }
	        }
	        return true; // Todos los enemigos han sido eliminados
	    }
	    
	    
	}
