import javax.swing.*;
import java.awt.*;

public class Nivel5 extends JFrame {
    private Jugador5 jugador5;
    private JPanel contentPane;
    private Enemigos6 enemigos;
    private int playerLives = 3;
    private JLabel lblVidas;
    private boolean isGameOver = false;
    private Timer movementTimer;
    private Timer shootingTimer;
    private Timer bulletMovementTimer;
    private JLabel lblNivel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Nivel5 frame = new Nivel5();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Nivel5() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        int bottomLimit = 574;
        enemigos = new Enemigos6(contentPane, bottomLimit);

        jugador5 = new Jugador5(this, enemigos);

        lblVidas = new JLabel("Lives: " + playerLives);
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        lblNivel = new JLabel("Level 5");
        lblNivel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNivel.setForeground(Color.WHITE);
        lblNivel.setBounds(600, 620, 100, 30);
        contentPane.add(lblNivel);
        
        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(Color.RED);
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);
    }

    private void gameOver() {
        stopTimers();
        isGameOver = true;

        JOptionPane.showMessageDialog(this, "Game Over", "Game Over", JOptionPane.INFORMATION_MESSAGE);

        Juego.setVidas(3);
        int option = JOptionPane.showOptionDialog(this,
            "¿Deseas volver al menú o salir del juego?",
            "Fin del juego",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new Object[]{"Volver al Menú", "Salir"},
            "Volver al Menú");

        if (option == JOptionPane.YES_OPTION) {
            volverAlMenu();
        } else {
            System.exit(0);
        }
    }

    private void stopTimers() {
        if (movementTimer != null) movementTimer.stop();
        if (shootingTimer != null) shootingTimer.stop();
        if (bulletMovementTimer != null) bulletMovementTimer.stop();
    }

    private void pauseGame() {
        stopTimers();
    }

    private void volverAlMenu() {
        this.dispose();
        Fondo menu = new Fondo();
        menu.setVisible(true);
    }

    public void loseLife() {
        if (playerLives > 0) {
            playerLives--;
            lblVidas.setText("Lives: " + playerLives);
        }
        if (playerLives <= 0 && !isGameOver) {
            gameOver();
        }
    }

    public void loseLifeFromEnemyBullet() {
        loseLife();
    }

    public void showVictoryMessage() {
        stopTimers();
        JOptionPane.showMessageDialog(this, "¡Victoria!", "¡Ganaste!", JOptionPane.INFORMATION_MESSAGE);

        int option = JOptionPane.showOptionDialog(this,
            "¿Deseas volver al menú o salir del juego?",
            "Victoria",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new Object[]{"Volver al Menú", "Salir"},
            "Volver al Menú");

        if (option == JOptionPane.YES_OPTION) {
            volverAlMenu();
        } else {
            System.exit(0);
        }
    }
}