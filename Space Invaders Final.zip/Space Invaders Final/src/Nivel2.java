import javax.swing.*;
import java.awt.*;

public class Nivel2 extends JFrame {
    private Jugador2 jugador2; 
    private JPanel contentPane;
    private Enemigos3 enemigos; 
    private JLabel lblVidas;
    private boolean levelCompleted = false;
    private JLabel lblNivel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Nivel2 frame = new Nivel2();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Nivel2() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700); 
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Inicializar enemigos
        int bottomLimit = 574; // Ajusta el límite inferior según sea necesario
        enemigos = new Enemigos3(contentPane, bottomLimit);

        // Inicializar el jugador con la referencia a los enemigos
        jugador2 = new Jugador2(this, enemigos);

        // Inicializar vidas
        lblVidas = new JLabel("Lives: " + Juego.getVidas());
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        lblNivel = new JLabel("Level 2");
        lblNivel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNivel.setForeground(Color.WHITE);
        lblNivel.setBounds(600, 620, 100, 30);
        contentPane.add(lblNivel);
        
        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(Color.RED);
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);

        // Agrega un temporizador para verificar el estado del nivel
        Timer timer = new Timer(100, e -> checkLevelComplete());
        timer.start();
    }

    public void loseLife() {
        Juego.setVidas(Juego.getVidas() - 1);
        lblVidas.setText("Lives: " + Juego.getVidas());
        if (Juego.getVidas() <= 0) {
            gameOver();
        }
    }

    public void loseLifeFromEnemyBullet() {
        loseLife();
    }

    private void gameOver() {
        // Detener los timers y otras acciones necesarias
        enemigos.stopTimers(); 

        // Mostrar el mensaje de Game Over
        JOptionPane.showMessageDialog(this, "Game Over", "Game Over", JOptionPane.INFORMATION_MESSAGE);

        Juego.setVidas(3);
        // Opciones después del Game Over
        int option = JOptionPane.showOptionDialog(this,
            "¿Deseas volver al menú o salir del juego?",
            "Fin del juego",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new Object[]{"Volver al Menú", "Salir"},
            "Volver al Menú");

        if (option == JOptionPane.YES_OPTION) {
            volverAlMenu();
        } else {
            System.exit(0);
        }
    }

    private void volverAlMenu() {
        // Ocultar el nivel actual y mostrar el menú principal
        this.dispose(); // Cierra la ventana actual

        Fondo menu = new Fondo(); // Asumiendo que Fondo es la clase del menú
        menu.setVisible(true); // Mostrar el menú principal
    }

    public void checkLevelComplete() {
        if (!levelCompleted && enemigos.allEnemiesRemoved()) {
            levelCompleted = true; // Asegúrate de que solo se abra una vez
            // Cambiar a Nivel3
            this.dispose(); // Cierra el nivel 2
            SwingUtilities.invokeLater(() -> {
                Nivel3 nivel3 = new Nivel3(); 
                nivel3.setVisible(true);
            });
        }
    }
}
