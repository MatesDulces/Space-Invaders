
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class Jugador5 extends JLabel {
    private int playerSpeed = 10;
    private boolean player1Left = false;
    private boolean player1Right = false;
    private List<JPanel> balas;
    private Timer disparoDelayTimer;
    private boolean canShoot = true;
    private Enemigos6 enemigos;
   
    private static final int PLAYER_WIDTH = 50;
    private static final int PLAYER_HEIGHT = 50;

    public Jugador5(JFrame frame, Enemigos6 enemigos) {
        // Load and scale the player image
        ImageIcon playerIcon = new ImageIcon("nave.png");
        Image playerImage = playerIcon.getImage().getScaledInstance(PLAYER_WIDTH, PLAYER_HEIGHT, Image.SCALE_SMOOTH);
        this.setIcon(new ImageIcon(playerImage));

        this.enemigos = enemigos;
        this.balas = new ArrayList<>();
        setBounds(195, 586, PLAYER_WIDTH, PLAYER_HEIGHT);
        frame.getContentPane().add(this);

        frame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                handleKeyRelease(e);
            }
        });

        Timer playerMovementTimer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                movePlayers(frame);
                updateBalas();
            }
        });
        playerMovementTimer.start();
    }

    private void handleKeyPress(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            player1Left = true;
        } else if (key == KeyEvent.VK_RIGHT) {
            player1Right = true;
        } else if (key == KeyEvent.VK_SPACE && canShoot) {
            shoot();
        }
    }

    private void handleKeyRelease(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            player1Left = false;
        } else if (key == KeyEvent.VK_RIGHT) {
            player1Right = false;
        }
    }

    private void movePlayers(JFrame frame) {
        int x = getX();
        int y = getY();
        int frameWidth = frame.getWidth();
        int playerWidth = getWidth();

        if (player1Left && x > 0) {
            setLocation(Math.max(x - playerSpeed, 0), y);
        }
        if (player1Right && x < frameWidth - playerWidth) {
            setLocation(Math.min(x + playerSpeed, frameWidth - playerWidth), y);
        }
    }

    private void shoot() {
        int x = getX() + (getWidth() / 2) - 2;
        int y = getY() - 10;

        JPanel nuevaBala = new JPanel();
        nuevaBala.setBackground(Color.RED);
        nuevaBala.setOpaque(true);
        nuevaBala.setBounds(x, y, 5, 10);
       
        getParent().add(nuevaBala);
        balas.add(nuevaBala);

        canShoot = false;
        disparoDelayTimer = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                canShoot = true;
                disparoDelayTimer.stop();
            }
        });
        disparoDelayTimer.start();
    }

    private void updateBalas() {
        List<JPanel> toRemoveBala = new ArrayList<>();
        for (JPanel bala : balas) {
            bala.setLocation(bala.getX(), bala.getY() - 15);
            if (bala.getY() < 0) {
                toRemoveBala.add(bala);
                getParent().remove(bala);
            } else if (checkCollision(bala)) {
                toRemoveBala.add(bala);
                getParent().remove(bala);
            }
        }
        balas.removeAll(toRemoveBala);
    }

    private boolean checkCollision(JPanel bala) {
        Rectangle bulletBounds = bala.getBounds();
        for (int row = 0; row < enemigos.getNumRows(); row++) {
            for (int col = 0; col < enemigos.getNumEnemiesPerRow(); col++) {
                JPanel enemigo = enemigos.getEnemy(row, col);
                if (enemigo != null) {
                    Rectangle enemyBounds = enemigo.getBounds();
                    if (bulletBounds.intersects(enemyBounds)) {
                        enemigos.removeEnemy(row, col);
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
