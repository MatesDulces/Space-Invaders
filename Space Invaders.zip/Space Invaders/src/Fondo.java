import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Fondo extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fondo frame = new Fondo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private static void presentarNivel1() {
		Nivel1 miNivel1 = new Nivel1();
		miNivel1.setVisible(true);
		}
	private static void presentarNivel2() {
		Nivel2 miNivel2 = new Nivel2();
		miNivel2.setVisible(true);
		}
	private static void presentarNivel3() {
		Nivel3 miNivel3 = new Nivel3();
		miNivel3.setVisible(true);
		}
	/**
	 * Create the frame.
	 */
	public Fondo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 50, 700, 700);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("NIVEL 3");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				presentarNivel3();
			}
		});
		btnNewButton.setBounds(492, 348, 100, 100);
		contentPane.add(btnNewButton);
		
		JButton btnNivel = new JButton("NIVEL 2");
		btnNivel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				presentarNivel2();
			}
		});
		btnNivel.setBounds(294, 348, 100, 100);
		contentPane.add(btnNivel);
		
		JButton btnNewButton_1_1 = new JButton("NIVEL 1");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				presentarNivel1();
			}
		});
		btnNewButton_1_1.setBounds(101, 348, 100, 100);
		contentPane.add(btnNewButton_1_1);
		
		JLabel lblNewLabel = new JLabel("SPACE INVADERS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblNewLabel.setBounds(142, 92, 384, 109);
		contentPane.add(lblNewLabel);
	}
}
