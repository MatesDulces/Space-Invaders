import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Enemigos {
    private static final int PANEL_SIZE = 31;
    private static final int NUM_ENEMIES = 8;
    private static final int MOVE_STEP = 1;
    private static final int TIMER_DELAY = 10;
    
    private JPanel[] enemyPanels = new JPanel[NUM_ENEMIES];
    private int direction = 1;
    private boolean hitLeftEdge = false;
    private boolean hitRightEdge = false;
    private Timer timer;
    private JPanel parentPanel;

    public Enemigos(JPanel parent) {
        this.parentPanel = parent;
        initializeEnemies();
        startMovement();
    }

    private void initializeEnemies() {
        for (int i = 0; i < NUM_ENEMIES; i++) {
            enemyPanels[i] = new JPanel();
            enemyPanels[i].setBackground(Color.RED);
            enemyPanels[i].setBounds(63 + i * (PANEL_SIZE + 5), 11, PANEL_SIZE, PANEL_SIZE);
            parentPanel.add(enemyPanels[i]);
        }
    }

    private void startMovement() {
        timer = new Timer(TIMER_DELAY, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveEnemies();
            }
        });
        timer.start();
    }

    private void moveEnemies() {
        hitLeftEdge = false;
        hitRightEdge = false;
        for (JPanel panel : enemyPanels) {
            if (panel.getX() <= 0) {
                hitLeftEdge = true;
            }
            if (panel.getX() + PANEL_SIZE >= parentPanel.getWidth()) {
                hitRightEdge = true;
            }
        }

        if (hitLeftEdge) {
            direction = 1;
            moveDown();
        } else if (hitRightEdge) {
            direction = -1;
            moveDown();
        }

        for (JPanel panel : enemyPanels) {
            int newX = panel.getX() + MOVE_STEP * direction;
            if (newX >= 0 && newX + PANEL_SIZE <= parentPanel.getWidth()) {
                panel.setLocation(newX, panel.getY());
            }
        }
    }

    private void moveDown() {
        for (JPanel panel : enemyPanels) {
            panel.setLocation(panel.getX(), panel.getY() + PANEL_SIZE / 2);
        }
    }
}