import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

public class Nivel3 extends JFrame {
    private JPanel contentPane;
    private Jugador jugador;
    private Enemigos enemigos;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Nivel3 frame = new Nivel3();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Nivel3() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Nivel3");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
        lblNewLabel.setForeground(Color.WHITE);
        lblNewLabel.setBounds(279, 186, 146, 178);
        contentPane.add(lblNewLabel);

        // Crear e inicializar el jugador
        jugador = new Jugador(this);

        // Crear e inicializar los enemigos
        enemigos = new Enemigos(contentPane);

        // Aseg�rate de que el frame sea focusable
        this.setFocusable(true);
        this.requestFocusInWindow();
    }
}