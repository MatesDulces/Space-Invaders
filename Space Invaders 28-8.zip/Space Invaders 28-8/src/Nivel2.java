import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Nivel2 extends JFrame {
    private Jugador2 jugador2;
    private JPanel contentPane;
    private Enemigos3 enemigos;
    private int vidas;
    private JLabel lblVidas;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Nivel2 frame = new Nivel2();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Nivel2() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Inicializar enemigos
        int bottomLimit = 574;
        enemigos = new Enemigos3(contentPane, bottomLimit);

        // Inicializar el jugador con la referencia a los enemigos
        jugador2 = new Jugador2(this, enemigos); // Pasa la instancia correcta

        // Inicializar vidas
        vidas = 3;
        lblVidas = new JLabel("Vidas: " + vidas);
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(Color.RED);
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);
    }

    public void loseLife() {
        vidas--;
        lblVidas.setText("Vidas: " + vidas);

        if (vidas <= 0) {
            // Manejar la finalizaci�n del juego
            JOptionPane.showMessageDialog(this, "Game Over!");
            System.exit(0);
        }
    }

    public void loseLifeFromEnemyBullet() {
        vidas--;
        lblVidas.setText("Vidas: " + vidas);

        if (vidas <= 0) {
            // Manejar la finalizaci�n del juego
            JOptionPane.showMessageDialog(this, "Game Over!");
            System.exit(0);
        }
    }
}
