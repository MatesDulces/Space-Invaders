import javax.swing.*;
import java.awt.*;

public class Nivel4 extends JFrame {
    private Jugador4 jugador4;
    private JPanel contentPane;
    private Enemigos5 enemigos;
    private int vidas;
    private JLabel lblVidas;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Nivel4 frame = new Nivel4();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Nivel4() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Inicializar enemigos
        int bottomLimit = 574;
        enemigos = new Enemigos5(contentPane, bottomLimit);

        // Inicializar el jugador con la referencia a los enemigos
        jugador4 = new Jugador4(this, enemigos);

        // Inicializar vidas
        vidas = 3;
        lblVidas = new JLabel("Vidas: " + vidas);
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(Color.RED);
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);
    }
    
    public Jugador4 getJugador() {
        return jugador4;
    }

    public void loseLife() {
        vidas--;
        lblVidas.setText("Vidas: " + vidas);

        if (vidas <= 0) {
            JOptionPane.showMessageDialog(this, "Game Over!");
            System.exit(0);
        }
    }
}
