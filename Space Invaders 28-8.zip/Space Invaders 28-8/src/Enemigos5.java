import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Enemigos5 {
	private static final int PANEL_SIZE = 31; // Tama�o del enemigo
    private static final int NUM_ENEMIES_PER_ROW = 10; // N�mero de enemigos por fila
    private static final int NUM_ROWS = 4; // N�mero de filas de enemigos
    private static final int MOVE_STEP = 1; // Paso de movimiento horizontal
    private static final int TIMER_DELAY = 15; // Retraso del temporizador en milisegundos
    private static final int MOVE_DOWN_STEP = 20; // Paso de movimiento vertical
    private static final int HORIZONTAL_GAP = 20; // Espacio horizontal entre enemigos
    private static final int VERTICAL_GAP = 20; // Espacio vertical entre enemigos
    private static final int BULLET_DELAY = 1000; // Retraso para disparos enemigos en milisegundos
    private static final int BULLET_MOVE_STEP = 5; // Paso de movimiento de la bala
    private static final int BULLET_MOVE_INTERVAL = 10; // Intervalo de actualizaci�n de las balas en milisegundos

    private JPanel[][] enemyPanels = new JPanel[NUM_ROWS][NUM_ENEMIES_PER_ROW];
    private int[][] shields = new int[NUM_ROWS][NUM_ENEMIES_PER_ROW]; // Matriz de escudos
    private int direction = 1;
    private boolean hitLeftEdge = false;
    private boolean hitRightEdge = false;
    private Timer movementTimer;
    private Timer shootingTimer;
    private Timer bulletMovementTimer;
    private JPanel parentPanel;
    private int bottomLimit;
    private Nivel4 nivel4;
    private Image enemyImage;
    private List<JPanel> enemyBullets = new ArrayList<>();

    public Enemigos5(JPanel parent, int bottomLimit) {
        this.parentPanel = parent;
        this.bottomLimit = bottomLimit;
        this.nivel4 = (Nivel4) SwingUtilities.getWindowAncestor(parent);
        this.enemyImage = new ImageIcon("enemies.png").getImage();
        initializeEnemies();
        startMovement();
        startShooting();
        startBulletMovement();
    }

    private void initializeEnemies() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        g.drawImage(enemyImage, 0, 0, PANEL_SIZE, PANEL_SIZE, this);
                    }
                };
                panel.setBackground(Color.BLACK);
                panel.setBounds(
                    63 + col * (PANEL_SIZE + HORIZONTAL_GAP),
                    11 + row * (PANEL_SIZE + VERTICAL_GAP),
                    PANEL_SIZE, PANEL_SIZE
                );
                parentPanel.add(panel);
                enemyPanels[row][col] = panel;
                shields[row][col] = 2; // Inicializar escudos a 2
            }
        }
    }

    public void startMovement() {
        movementTimer = new Timer();
        movementTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                moveEnemies();
            }
        }, 0, TIMER_DELAY);
    }

    public void startShooting() {
        shootingTimer = new Timer();
        shootingTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                shootFromRandomEnemy();
            }
        }, BULLET_DELAY, BULLET_DELAY);
    }

    private void startBulletMovement() {
        bulletMovementTimer = new Timer();
        bulletMovementTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                moveBullets();
            }
        }, 0, BULLET_MOVE_INTERVAL);
    }

    private void moveEnemies() {
        hitLeftEdge = false;
        hitRightEdge = false;

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int newX = panel.getX() + MOVE_STEP * direction;
                    if (newX <= 0) {
                        hitLeftEdge = true;
                    }
                    if (newX >= parentPanel.getWidth() - panel.getWidth()) {
                        hitRightEdge = true;
                    }
                }
            }
        }

        if (hitLeftEdge || hitRightEdge) {
            direction *= -1;
            moveEnemiesDown();
        }

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    panel.setLocation(panel.getX() + MOVE_STEP * direction, panel.getY());
                }
            }
        }
    }

    private void moveEnemiesDown() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int newY = panel.getY() + MOVE_DOWN_STEP;
                    panel.setLocation(panel.getX(), newY);

                    if (newY + panel.getHeight() >= bottomLimit) {
                        nivel4.loseLife();
                        panel.setVisible(false);
                        enemyPanels[row][col] = null;
                    }
                }
            }
        }
    }

    private void shootFromRandomEnemy() {
        List<JPanel> availableEnemies = new ArrayList<>();
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    availableEnemies.add(panel);
                }
            }
        }

        if (!availableEnemies.isEmpty()) {
            JPanel shooter = availableEnemies.get(new Random().nextInt(availableEnemies.size()));
            int x = shooter.getX() + PANEL_SIZE / 2 - 2;
            int y = shooter.getY() + PANEL_SIZE;

            JPanel bullet = new JPanel();
            bullet.setBackground(Color.YELLOW);
            bullet.setBounds(x, y, 5, 10);
            parentPanel.add(bullet);
            enemyBullets.add(bullet);
        }
    }

    private void moveBullets() {
        List<JPanel> toRemoveBullets = new ArrayList<>();
        for (JPanel bullet : enemyBullets) {
            bullet.setLocation(bullet.getX(), bullet.getY() + BULLET_MOVE_STEP);
            if (bullet.getY() > bottomLimit) {
                toRemoveBullets.add(bullet);
                parentPanel.remove(bullet);
            } else if (bullet.getBounds().intersects(nivel4.getJugador().getBounds())) {
                toRemoveBullets.add(bullet);
                parentPanel.remove(bullet);
                nivel4.loseLife();
            }
        }
        enemyBullets.removeAll(toRemoveBullets);
    }

    public JPanel getEnemy(int row, int col) {
        return enemyPanels[row][col];
    }

    public boolean reduceShield(int row, int col) {
        shields[row][col]--;
        return shields[row][col] <= 0;
    }

    public void removeEnemy(int row, int col) {
        JPanel panel = enemyPanels[row][col];
        if (panel != null) {
            parentPanel.remove(panel);
            enemyPanels[row][col] = null;
        }
    }

    public int getNumEnemiesPerRow() {
        return NUM_ENEMIES_PER_ROW;
    }

    public int getNumRows() {
        return NUM_ROWS;
    }
}
