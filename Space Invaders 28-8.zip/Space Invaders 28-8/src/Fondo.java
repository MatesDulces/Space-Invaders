import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Ellipse2D;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

public class Fondo extends JFrame {

    private JPanel contentPane;
    private JButton[] buttons;
    private int selectedIndex = 0;
    private Timer blinkTimer;
    private boolean isBlinking = false;
    private JLabel leftArrow;
    private JLabel rightArrow;

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            try {
                Fondo frame = new Fondo();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private static void presentarNivel1() {
        Nivel1 miNivel1 = new Nivel1();
        miNivel1.setVisible(true);
    }

    private static void presentarNivel2() {
        Nivel2 miNivel2 = new Nivel2();
        miNivel2.setVisible(true);
    }

    private static void presentarNivel3() {
        Nivel3 miNivel3 = new Nivel3();
        miNivel3.setVisible(true);
    }

    private static void salir() {
        System.exit(0); // Salir de la aplicaci�n
    }

    public Fondo() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);

        contentPane = new SpaceBackgroundPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        ImageIcon originalIcon = new ImageIcon("logo.png");
        Image img = originalIcon.getImage();
        Image scaledImg = img.getScaledInstance(384, 109, Image.SCALE_SMOOTH);
        JLabel lblTitle = new JLabel(new ImageIcon(scaledImg));
        lblTitle.setBounds(142, 50, 384, 109);
        contentPane.add(lblTitle);

        // Inicializar las flechitas
        leftArrow = new JLabel(">>");
        rightArrow = new JLabel("<<");
        leftArrow.setFont(leftArrow.getFont().deriveFont(20f));
        rightArrow.setFont(rightArrow.getFont().deriveFont(20f));
        leftArrow.setForeground(Color.YELLOW);
        rightArrow.setForeground(Color.YELLOW);
        leftArrow.setBounds(100, 250, 30, 50); // Ajusta la posici�n inicial
        rightArrow.setBounds(470, 250, 30, 50); // Ajusta la posici�n inicial
        leftArrow.setVisible(false); // Ocultar inicialmente
        rightArrow.setVisible(false); // Ocultar inicialmente
        contentPane.add(leftArrow);
        contentPane.add(rightArrow);

        // Crear los botones
        JButton btnNivel1 = createButton("LEVEL 1", 250, 250, e -> presentarNivel1());
        JButton btnNivel2 = createButton("LEVEL 2", 250, 320, e -> presentarNivel2());
        JButton btnNivel3 = createButton("LEVEL 3", 250, 390, e -> presentarNivel3());
        JButton btnQuitGame = createButton("QUIT GAME", 250, 460, e -> salir());

        buttons = new JButton[]{btnNivel1, btnNivel2, btnNivel3, btnQuitGame};

        // Inicializar el bot�n seleccionado
        updateButtonSelection();

        // Configurar el KeyListener
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
            @Override
            public void keyReleased(KeyEvent e) {}
        });
        setFocusable(true); // Aseg�rate de que el frame pueda recibir el foco
    }

    private JButton createButton(String text, int x, int y, ActionListener actionListener) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 50);
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFont(button.getFont().deriveFont(20f));
        button.setFocusPainted(false); // Elimina el borde de enfoque
        button.setBorderPainted(false); // Elimina el borde del bot�n
        button.addActionListener(actionListener);
        contentPane.add(button);
        return button;
    }

    private void handleKeyPress(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
            selectPreviousButton();
        } else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
            selectNextButton();
        } else if (key == KeyEvent.VK_ENTER || key == KeyEvent.VK_SPACE) {
            buttons[selectedIndex].doClick();
        }
    }

    private void selectPreviousButton() {
        selectedIndex = (selectedIndex - 1 + buttons.length) % buttons.length;
        updateButtonSelection();
    }

    private void selectNextButton() {
        selectedIndex = (selectedIndex + 1) % buttons.length;
        updateButtonSelection();
    }

    private void updateButtonSelection() {
        if (blinkTimer != null) {
            blinkTimer.stop();
        }
        for (int i = 0; i < buttons.length; i++) {
            JButton button = buttons[i];
            if (i == selectedIndex) {
                // Efecto de titilaci�n en el texto
                blinkTimer = new Timer(500, e -> {
                    if (isBlinking) {
                        button.setForeground(Color.WHITE); // Texto en color blanco
                    } else {
                        button.setForeground(Color.BLACK); // Texto en color amarillo
                    }
                    isBlinking = !isBlinking;
                });
                blinkTimer.start();

                // Mostrar flechitas y ajustar su posici�n
                leftArrow.setVisible(true);
                rightArrow.setVisible(true);
                // Ajustar la distancia de las flechitas al bot�n
                int arrowOffset = 0; // Distancia entre el bot�n y las flechitas
                leftArrow.setBounds(button.getX() - leftArrow.getWidth() - arrowOffset, button.getY(), leftArrow.getWidth(), leftArrow.getHeight());
                rightArrow.setBounds(button.getX() + button.getWidth() + arrowOffset, button.getY(), rightArrow.getWidth(), rightArrow.getHeight());
            } else {
                button.setForeground(Color.WHITE); // Texto de otros botones
            }
        }
    }


    private static class SpaceBackgroundPanel extends JPanel {
        private static final int STAR_COUNT = 100;

        public SpaceBackgroundPanel() {
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;

            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setPaint(new Color(0, 0, 0));
            g2d.fillRect(0, 0, getWidth(), getHeight());

            Random random = new Random();
            g2d.setColor(Color.WHITE);
            for (int i = 0; i < STAR_COUNT; i++) {
                int x = random.nextInt(getWidth());
                int y = random.nextInt(getHeight());
                int size = random.nextInt(3) + 1;
                g2d.fill(new Ellipse2D.Double(x, y, size, size));
            }
        }
    }
}