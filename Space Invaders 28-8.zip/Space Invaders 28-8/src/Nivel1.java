import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Nivel1 extends JFrame {
    private JPanel contentPane;
    private Jugador jugador;
    private Enemigos2 enemigos;
    private JLabel lblVidas;
    private int vidas;

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            try {
                Nivel1 frame = new Nivel1();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Nivel1() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Inicializar vidas
        vidas = 3;
        lblVidas = new JLabel("Vidas: " + vidas);
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        // Crear e inicializar los enemigos con l�mite inferior
        int bottomLimit = 574;
        enemigos = new Enemigos2(contentPane, bottomLimit);

        // Crear e inicializar el jugador con la referencia a los enemigos
        jugador = new Jugador(this, enemigos);

        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(new Color(255, 0, 0));
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);

        // Aseg�rate de que el frame sea focusable
        this.setFocusable(true);
        this.requestFocusInWindow();
    }

    public void loseLife() {
        vidas--;
        lblVidas.setText("Vidas: " + vidas);

        if (vidas <= 0) {
            //showGameOver();
        }
    }

}
