import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Enemigos4 {
    private static final int PANEL_SIZE = 31;
    private static final int NUM_ENEMIES_PER_ROW = 10;
    private static final int NUM_ROWS = 4;
    private static final int MOVE_STEP = 1;
    private static final int TIMER_DELAY = 15;
    private static final int MOVE_DOWN_STEP = 20;
    private static final int HORIZONTAL_GAP = 20;
    private static final int VERTICAL_GAP = 20;
    private static final int BULLET_DELAY = 1000;
    private static final int BULLET_MOVE_STEP = 5;
    private static final int BULLET_MOVE_INTERVAL = 10;
    private static final int KAMIKAZE_SPEED = 5;  // Velocidad aumentada

    private JPanel[][] enemyPanels = new JPanel[NUM_ROWS][NUM_ENEMIES_PER_ROW];
    private int direction = 1;
    private boolean hitLeftEdge = false;
    private boolean hitRightEdge = false;
    private Timer movementTimer;
    private Timer shootingTimer;
    private Timer bulletMovementTimer;
    private Timer kamikazeTimer;
    private JPanel parentPanel;
    private int bottomLimit;
    private Nivel3 nivel3;
    private Image enemyImage;
    private List<JPanel> enemyBullets = new ArrayList<>();

    public Enemigos4(JPanel parent, int bottomLimit) {
        this.parentPanel = parent;
        this.bottomLimit = bottomLimit;
        this.nivel3 = (Nivel3) SwingUtilities.getWindowAncestor(parent);
        this.enemyImage = new ImageIcon("enemies.png").getImage();
        initializeEnemies();
        startMovement();
        startShooting();
        startBulletMovement();
        startKamikazeAttack();  // Iniciar ataques kamikaze
    }

    private void initializeEnemies() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        g.drawImage(enemyImage, 0, 0, PANEL_SIZE, PANEL_SIZE, this);
                    }
                };
                panel.setBackground(Color.BLACK);
                panel.setBounds(
                    63 + col * (PANEL_SIZE + HORIZONTAL_GAP),
                    11 + row * (PANEL_SIZE + VERTICAL_GAP),
                    PANEL_SIZE, PANEL_SIZE
                );
                parentPanel.add(panel);
                enemyPanels[row][col] = panel;
            }
        }
    }

    private void startMovement() {
        movementTimer = new Timer();
        movementTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> moveEnemies());
            }
        }, 0, TIMER_DELAY);
    }

    private void startShooting() {
        shootingTimer = new Timer();
        shootingTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> shoot());
            }
        }, 0, BULLET_DELAY);
    }

    private void startBulletMovement() {
        bulletMovementTimer = new Timer();
        bulletMovementTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> moveBullets());
            }
        }, 0, BULLET_MOVE_INTERVAL);
    }

    private void startKamikazeAttack() {
        kamikazeTimer = new Timer();
        kamikazeTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> initiateKamikaze());
            }
        }, 0, 5000 + new Random().nextInt(5000)); // Intervalo aleatorio entre 5 y 10 segundos
    }

    private void initiateKamikaze() {
        Random rand = new Random();
        int row = rand.nextInt(NUM_ROWS);
        int col = rand.nextInt(NUM_ENEMIES_PER_ROW);
        JPanel enemy = enemyPanels[row][col];

        if (enemy != null) {
            int initialX = enemy.getX();
            int initialY = enemy.getY();
            Timer kamikazeMovementTimer = new Timer();

            kamikazeMovementTimer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    SwingUtilities.invokeLater(() -> {
                        Component[] components = parentPanel.getComponents();
                        Jugador3 player = null;
                        for (Component component : components) {
                            if (component instanceof Jugador3) {
                                player = (Jugador3) component;
                                break;
                            }
                        }
                        if (player != null) {
                            // Movimiento directo hacia el jugador
                            int playerX = player.getX();
                            int playerY = player.getY();

                            int deltaX = playerX - enemy.getX();
                            int deltaY = playerY - enemy.getY();

                            double angle = Math.atan2(deltaY, deltaX);
                            int newX = (int) (enemy.getX() + KAMIKAZE_SPEED * Math.cos(angle));
                            int newY = (int) (enemy.getY() + KAMIKAZE_SPEED * Math.sin(angle));
                            enemy.setLocation(newX, newY);

                            if (enemy.getBounds().intersects(player.getBounds())) {
                                if (!player.isInvincible()) {  // Verifica que el jugador no sea invencible
                                    nivel3.loseLife();
                                    player.setInvincible(true); // Activa invencibilidad temporal para prevenir múltiples pérdidas
                                    enemy.setLocation(initialX, initialY);
                                    kamikazeMovementTimer.cancel();
                                }
                            } else if (newY >= bottomLimit) {
                                enemy.setLocation(initialX, initialY);
                                kamikazeMovementTimer.cancel();
                            }
                        }
                    });
                }
            }, 0, 15); // Movimiento continuo hacia el jugador
        }
    }

    private void moveEnemies() {
        hitLeftEdge = false;
        hitRightEdge = false;

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    if (panel.getX() <= 0) {
                        hitLeftEdge = true;
                    }
                    if (panel.getX() + PANEL_SIZE >= parentPanel.getWidth()) {
                        hitRightEdge = true;
                    }
                }
            }
        }

        if (hitLeftEdge) {
            direction = 1;
            moveDown();
        } else if (hitRightEdge) {
            direction = -1;
            moveDown();
        }

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int newX = panel.getX() + MOVE_STEP * direction;
                    if (newX >= 0 && newX + PANEL_SIZE <= parentPanel.getWidth()) {
                        panel.setLocation(newX, panel.getY());
                    }
                }
            }
        }
    }

    private void moveDown() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int newY = panel.getY() + MOVE_DOWN_STEP;
                    if (newY >= bottomLimit - 10) {
                        nivel3.loseLife();
                        newY = 11;
                    }
                    panel.setLocation(panel.getX(), newY);
                }
            }
        }
    }

    private void shoot() {
        Random rand = new Random();
        int row = rand.nextInt(NUM_ROWS);
        int col = rand.nextInt(NUM_ENEMIES_PER_ROW);
        JPanel enemy = enemyPanels[row][col];

        if (enemy != null) {
            int x = enemy.getX() + PANEL_SIZE / 2 - 2;
            int y = enemy.getY() + PANEL_SIZE;

            JPanel bullet = new JPanel();
            bullet.setBackground(Color.GREEN);
            bullet.setOpaque(true);
            bullet.setBounds(x, y, 4, 10);

            parentPanel.add(bullet);
            enemyBullets.add(bullet);
        }
    }

    private void moveBullets() {
        List<JPanel> toRemoveBullets = new ArrayList<>();
        for (JPanel bullet : enemyBullets) {
            bullet.setLocation(bullet.getX(), bullet.getY() + BULLET_MOVE_STEP);
            if (bullet.getY() > parentPanel.getHeight() || checkBulletCollisionWithPlayer(bullet)) {
                toRemoveBullets.add(bullet);
                parentPanel.remove(bullet);
            }
        }
        enemyBullets.removeAll(toRemoveBullets);
    }

    private boolean checkBulletCollisionWithPlayer(JPanel bullet) {
        Rectangle bulletBounds = bullet.getBounds();
        Component[] components = parentPanel.getComponents();
        for (Component component : components) {
            if (component instanceof Jugador3) {
                Jugador3 player = (Jugador3) component;
                Rectangle playerBounds = player.getBounds();
                if (bulletBounds.intersects(playerBounds)) {
                    nivel3.loseLife();
                    return true;
                }
            }
        }
        return false;
    }

    public JPanel getEnemy(int row, int col) {
        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
            return enemyPanels[row][col];
        }
        return null;
    }

    public int getNumRows() {
        return NUM_ROWS;
    }

    public int getNumEnemiesPerRow() {
        return NUM_ENEMIES_PER_ROW;
    }

    public void removeEnemy(int row, int col) {
        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
            JPanel enemy = enemyPanels[row][col];
            if (enemy != null) {
                parentPanel.remove(enemy);
                enemyPanels[row][col] = null;
                parentPanel.repaint();
            }
        }
    }
}
