import javax.swing.*;
import java.awt.*;

public class Nivel3 extends JFrame {
    private Jugador3 jugador3;  // Usamos Jugador3 en lugar de Jugador2
    private JPanel contentPane;
    private Enemigos4 enemigos;  // Usamos Enemigos4 en lugar de Enemigos3
    private int vidas; 
    private JLabel lblVidas;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Nivel3 frame = new Nivel3();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Nivel3() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Inicializar enemigos
        int bottomLimit = 574;
        enemigos = new Enemigos4(contentPane, bottomLimit);  // Instancia de Enemigos4

        // Inicializar el jugador con la referencia a los enemigos
        jugador3 = new Jugador3(this, enemigos);  // Instancia de Jugador3

        // Inicializar vidas
        vidas = 3;
        lblVidas = new JLabel("Vidas: " + vidas);
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(Color.RED);
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);
    }

    public void loseLife() {
        vidas--;
        lblVidas.setText("Vidas: " + vidas);

        if (vidas <= 0) {
            // Manejar la finalización del juego
            JOptionPane.showMessageDialog(this, "Game Over!");
            System.exit(0);
        }
    }

    public void loseLifeFromEnemyBullet() {
        vidas--;
        lblVidas.setText("Vidas: " + vidas);

        if (vidas <= 0) {
            // Manejar la finalización del juego
            JOptionPane.showMessageDialog(this, "Game Over!");
            System.exit(0);
        }
    }
}
