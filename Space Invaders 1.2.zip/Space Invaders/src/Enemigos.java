import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Enemigos {
    private static final int PANEL_SIZE = 31;
    private static final int NUM_ENEMIES = 8;
    private static final int MOVE_STEP = 1;
    private static final int TIMER_DELAY = 10;
    
    private List<JPanel> enemyPanels = new ArrayList<>();
    private int direction = 1;
    private boolean hitLeftEdge = false;
    private boolean hitRightEdge = false;
    private Timer timer;
    private JPanel parentPanel;

    public Enemigos(JPanel parent) {
        this.parentPanel = parent;
        initializeEnemies();
        startMovement();
    }

    private void initializeEnemies() {
        for (int i = 0; i < NUM_ENEMIES; i++) {
            JPanel enemy = new JPanel();
            enemy.setBackground(Color.RED);
            enemy.setBounds(63 + i * (PANEL_SIZE + 5), 11, PANEL_SIZE, PANEL_SIZE);
            parentPanel.add(enemy);
            enemyPanels.add(enemy);
        }
    }

    private void startMovement() {
        timer = new Timer(TIMER_DELAY, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveEnemies();
            }
        });
        timer.start();
    }

    private void moveEnemies() {
        hitLeftEdge = false;
        hitRightEdge = false;
        for (JPanel panel : enemyPanels) {
            if (panel.getX() <= 0) {
                hitLeftEdge = true;
            }
            if (panel.getX() + PANEL_SIZE >= parentPanel.getWidth()) {
                hitRightEdge = true;
            }
        }
        if (hitLeftEdge) {
            direction = 1;
            moveDown();
        } else if (hitRightEdge) {
            direction = -1;
            moveDown();
        }
        for (JPanel panel : enemyPanels) {
            int newX = panel.getX() + MOVE_STEP * direction;
            if (newX >= 0 && newX + PANEL_SIZE <= parentPanel.getWidth()) {
                panel.setLocation(newX, panel.getY());
            }
        }
    }

    private void moveDown() {
        for (JPanel panel : enemyPanels) {
            panel.setLocation(panel.getX(), panel.getY() + PANEL_SIZE / 2);
        }
    }

    public boolean checkCollision(JPanel bala) {
        for (JPanel enemy : new ArrayList<>(enemyPanels)) {
            if (enemy.getBounds().intersects(bala.getBounds())) {
                parentPanel.remove(enemy);
                enemyPanels.remove(enemy);
                parentPanel.revalidate();
                parentPanel.repaint();
                return true;
            }
        }
        return false;
    }

    public boolean allEnemiesDestroyed() {
        return enemyPanels.isEmpty();
    }
}