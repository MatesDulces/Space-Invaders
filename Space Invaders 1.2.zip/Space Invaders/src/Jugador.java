import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.util.ArrayList;
import java.util.List;

public class Jugador {
    private JPanel player1;
    private int playerSpeed = 10;
    private boolean player1Left = false;
    private boolean player1Right = false;
    private List<JPanel> balas;
    private Timer disparoDelayTimer;
    private boolean canShoot = true;
    private Enemigos enemigos;

    public Jugador(JFrame frame, Enemigos enemigos) {
        this.enemigos = enemigos;
        balas = new ArrayList<>();
        initialize(frame);
    }

    private void initialize(JFrame frame) {
        player1 = new JPanel();
        player1.setBackground(Color.WHITE);
        player1.setBounds(195, 586, 20, 20);
        frame.getContentPane().add(player1);

        frame.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
            @Override
            public void keyReleased(KeyEvent e) {
                handleKeyRelease(e);
            }
        });

        Timer playerMovementTimer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                movePlayers(frame);
                updateBalas();
            }
        });
        playerMovementTimer.start();
    }

    private void handleKeyPress(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            player1Left = true;
        } else if (key == KeyEvent.VK_RIGHT) {
            player1Right = true;
        } else if (key == KeyEvent.VK_SPACE && canShoot) {
            shoot();
        }
    }

    private void handleKeyRelease(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            player1Left = false;
        } else if (key == KeyEvent.VK_RIGHT) {
            player1Right = false;
        }
    }

    private void movePlayers(JFrame frame) {
        int x = player1.getX();
        int y = player1.getY();
        int frameWidth = frame.getWidth();
        int playerWidth = player1.getWidth();

        if (player1Left && x > 0) {
            player1.setLocation(Math.max(x - playerSpeed, 0), y);
        }
        if (player1Right && x < frameWidth - playerWidth) {
            player1.setLocation(Math.min(x + playerSpeed, frameWidth - playerWidth), y);
        }
    }

    private void shoot() {
        int x = player1.getX() + (player1.getWidth() / 2) - 2;
        int y = player1.getY() - 10;

        JPanel nuevaBala = new JPanel();
        nuevaBala.setBackground(Color.RED);
        nuevaBala.setOpaque(true);
        nuevaBala.setBounds(x, y, 5, 10);
        
        player1.getParent().add(nuevaBala);
        balas.add(nuevaBala);

        canShoot = false;
        disparoDelayTimer = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                canShoot = true;
                disparoDelayTimer.stop();
            }
        });
        disparoDelayTimer.start();
    }

    private void updateBalas() {
        List<JPanel> toRemove = new ArrayList<>();
        for (JPanel bala : balas) {
            bala.setLocation(bala.getX(), bala.getY() - 15);
            if (bala.getY() < 0 || enemigos.checkCollision(bala)) {
                toRemove.add(bala);
                player1.getParent().remove(bala);
            }
        }
        balas.removeAll(toRemove);

        if (enemigos.allEnemiesDestroyed()) {
            System.out.println("�Todos los enemigos han sido destruidos!");
            // Aqu� puedes agregar l�gica para terminar el juego o pasar al siguiente nivel
        }
    }
}