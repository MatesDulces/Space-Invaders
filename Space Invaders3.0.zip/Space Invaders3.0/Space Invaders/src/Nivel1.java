import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Nivel1 extends JFrame {
    private JPanel contentPane;
    private Jugador jugador;
    private Enemigos2 enemigos;
    private JLabel lblVidas;
    private int vidas;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Nivel1 frame = new Nivel1();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Nivel1() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Inicializar vidas
        vidas = 3; // Puedes ajustar esto seg�n el dise�o del juego
        lblVidas = new JLabel("Vidas: " + vidas);
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        // Crear e inicializar los enemigos con l�mite inferior
        int bottomLimit = 574; // el l�mite inferior que has establecido
        enemigos = new Enemigos2(contentPane, bottomLimit);

        // Crear e inicializar el jugador con la referencia a los enemigos
        jugador = new Jugador(this, enemigos);

        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(new Color(255, 0, 0));
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);

        // Aseg�rate de que el frame sea focusable
        this.setFocusable(true);
        this.requestFocusInWindow();
    }

    public void loseLife() {
        vidas--;
        lblVidas.setText("Vidas: " + vidas);

        if (vidas <= 0) {
            showGameOver();
        }
    }

    private void showGameOver() {
        int response = JOptionPane.showOptionDialog(
            this,
            "Game Over\n�Quieres volver al men�?",
            "Game Over",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            new Object[]{"S�", "No"},
            "S�"
        );

        if (response == JOptionPane.YES_OPTION) {
            // Volver al men�
            this.dispose(); // Cierra el frame actual
            Fondo.main(null); // Abre el men� principal
        } else {
            System.exit(0); // Salir del juego si el usuario elige "No"
        }
    }
}
